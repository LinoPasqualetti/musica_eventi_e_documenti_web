const { Event, Song } = require('../models');
const { Op } = require('sequelize');

const eventController = {
  // GET /api/events - Lista eventi con filtri
  async getAllEvents(req, res) {
    try {
      const { category, difficulty, status, search, page = 1, limit = 20 } = req.query;
      const offset = (page - 1) * limit;
      
      const where = {};
      if (category) where.category = category;
      if (difficulty) where.difficulty = difficulty;
      if (status) where.status = status;
      if (search) {
        where[Op.or] = [
          { title: { [Op.like]: `%${search}%` } },
          { theme: { [Op.like]: `%${search}%` } },
          { description: { [Op.like]: `%${search}%` } }
        ];
      }
      
      const { count, rows } = await Event.findAndCountAll({
        where,
        order: [['date', 'ASC']],
        limit: parseInt(limit),
        offset: parseInt(offset)
      });
      
      res.json({
        success: true,
        data: rows,
        pagination: {
          total: count,
          page: parseInt(page),
          limit: parseInt(limit),
          totalPages: Math.ceil(count / limit)
        }
      });
    } catch (error) {
      console.error('Error fetching events:', error);
      res.status(500).json({
        success: false,
        message: 'Errore nel recupero degli eventi'
      });
    }
  },

  // GET /api/events/:id - Dettaglio evento
  async getEventById(req, res) {
    try {
      const { id } = req.params;
      const event = await Event.findByPk(id);
      
      if (!event) {
        return res.status(404).json({
          success: false,
          message: 'Evento non trovato'
        });
      }
      
      res.json({
        success: true,
        data: event
      });
    } catch (error) {
      console.error('Error fetching event:', error);
      res.status(500).json({
        success: false,
        message: 'Errore nel recupero dell\'evento'
      });
    }
  },

  // GET /api/events/:id/songs - Brani dell'evento (versione SEMPLIFICATA)
  async getEventSongs(req, res) {
    try {
      const { id } = req.params;
      
      console.log(`🔍 Cerco brani per evento: ${id}`);
      
      // Verifica che l'evento esista
      const event = await Event.findByPk(id);
      if (!event) {
        console.log(`❌ Evento ${id} non trovato`);
        return res.status(404).json({
          success: false,
          message: 'Evento non trovato'
        });
      }
      
      console.log(`✅ Evento trovato: ${event.title}`);
      
      // Query diretta SQL
      const sequelize = require('../config/database');
      const songs = await sequelize.query(`
        SELECT s.*, es.order_index, es.notes
        FROM songs s
        INNER JOIN event_songs es ON s.id = es.song_id
        WHERE es.event_id = ?
        ORDER BY es.order_index ASC
      `, {
        replacements: [id],
        type: sequelize.QueryTypes.SELECT
      });
      
      console.log(`📦 Trovati ${songs.length} brani per l'evento`);
      
      res.json({
        success: true,
        data: songs
      });
      
    } catch (error) {
      console.error('❌ ERRORE getEventSongs:', error);
      res.status(500).json({
        success: false,
        message: 'Errore nel recupero dei brani dell\'evento',
        error: error.message
      });
    }
  }
};

module.exports = eventController;