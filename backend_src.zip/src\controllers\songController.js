const { Song, Document } = require('../models');
const { Op } = require('sequelize');

const songController = {
  async getAllSongs(req, res) {
    try {
      const { genre, difficulty, search, page = 1, limit = 20 } = req.query;
      const offset = (page - 1) * limit;
      
      const where = {};
      if (genre) where.genre = genre;
      if (difficulty) where.difficulty = difficulty;
      if (search) {
        where[Op.or] = [
          { title: { [Op.like]: `%${search}%` } },
          { composer: { [Op.like]: `%${search}%` } }
        ];
      }
      
      const { count, rows } = await Song.findAndCountAll({
        where,
        order: [['title', 'ASC']],
        limit: parseInt(limit),
        offset: parseInt(offset)
      });
      
      res.json({
        success: true,
        data: rows,
        pagination: {
          total: count,
          page: parseInt(page),
          limit: parseInt(limit),
          totalPages: Math.ceil(count / limit)
        }
      });
    } catch (error) {
      console.error('Error fetching songs:', error);
      res.status(500).json({
        success: false,
        message: 'Errore nel recupero delle canzoni'
      });
    }
  },

  async getSongById(req, res) {
    try {
      const { id } = req.params;
      const song = await Song.findByPk(id);
      
      if (!song) {
        return res.status(404).json({
          success: false,
          message: 'Canzone non trovata'
        });
      }
      
      res.json({
        success: true,
        data: song
      });
    } catch (error) {
      console.error('Error fetching song:', error);
      res.status(500).json({
        success: false,
        message: 'Errore nel recupero della canzone'
      });
    }
  },

  async getSongDocuments(req, res) {
    try {
      const { id } = req.params;
      const song = await Song.findByPk(id);
      if (!song) {
        return res.status(404).json({
          success: false,
          message: 'Canzone non trovata'
        });
      }
      
      const documents = await Document.findAll({
        include: [{
          model: Song,
          where: { id: id },
          through: { attributes: ['order_index', 'notes'] }
        }]
      });
      
      res.json({
        success: true,
        data: documents
      });
    } catch (error) {
      console.error('Error fetching song documents:', error);
      res.status(500).json({
        success: false,
        message: 'Errore nel recupero dei documenti della canzone'
      });
    }
  }
};

module.exports = songController;