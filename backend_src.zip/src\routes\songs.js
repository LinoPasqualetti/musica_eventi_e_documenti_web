const express = require('express');
const router = express.Router();
const songController = require('../controllers/songController');

router.get('/', songController.getAllSongs);
router.get('/:id', songController.getSongById);
router.get('/:id/documents', songController.getSongDocuments);

module.exports = router;