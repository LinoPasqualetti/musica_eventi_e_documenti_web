const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Event = sequelize.define('Event', {
  id: {
    type: DataTypes.STRING,
    primaryKey: true,
    allowNull: false
  },
  title: {
    type: DataTypes.STRING,
    allowNull: false
  },
  theme: {
    type: DataTypes.STRING,
    allowNull: false
  },
  description: {
    type: DataTypes.TEXT
  },
  image_url: {
    type: DataTypes.STRING
  },
  date: {
    type: DataTypes.DATE,
    allowNull: false
  },
  location: {
    type: DataTypes.STRING,
    allowNull: false
  },
  category: {
    type: DataTypes.STRING,
    defaultValue: 'concerto'
  },
  status: {
    type: DataTypes.STRING,
    defaultValue: 'published'
  },
  capacity: {
    type: DataTypes.INTEGER,
    defaultValue: 999
  },
  registration_deadline: {
    type: DataTypes.DATE
  },
  difficulty: {
    type: DataTypes.STRING,
    defaultValue: 'intermediate'
  },
  duration: {
    type: DataTypes.STRING
  },
  contact_email: {
    type: DataTypes.STRING
  },
  contact_phone: {
    type: DataTypes.STRING
  },
  video_url: {
    type: DataTypes.STRING
  },
  created_by: {
    type: DataTypes.STRING,
    allowNull: false
  },
  created_at: {
    type: DataTypes.DATE,
    allowNull: false
  },
  updated_at: {
    type: DataTypes.DATE
  }
}, {
  tableName: 'events',
  timestamps: false
});

module.exports = Event;