const { Document } = require('../models');
const { Op } = require('sequelize');
const path = require('path');
const fs = require('fs');

const documentController = {
  async getAllDocuments(req, res) {
    try {
      const { doc_type, is_public, search, page = 1, limit = 20 } = req.query;
      const offset = (page - 1) * limit;
      
      const where = {};
      if (doc_type) where.doc_type = doc_type;
      if (is_public !== undefined) where.is_public = is_public === 'true';
      if (search) {
        where[Op.or] = [
          { file_name: { [Op.like]: `%${search}%` } },
          { description: { [Op.like]: `%${search}%` } }
        ];
      }
      
      const { count, rows } = await Document.findAndCountAll({
        where,
        order: [['created_at', 'DESC']],
        limit: parseInt(limit),
        offset: parseInt(offset)
      });
      
      res.json({
        success: true,
        data: rows,
        pagination: {
          total: count,
          page: parseInt(page),
          limit: parseInt(limit),
          totalPages: Math.ceil(count / limit)
        }
      });
    } catch (error) {
      console.error('Error fetching documents:', error);
      res.status(500).json({
        success: false,
        message: 'Errore nel recupero dei documenti'
      });
    }
  },

  async getDocumentById(req, res) {
    try {
      const { id } = req.params;
      const document = await Document.findByPk(id);
      
      if (!document) {
        return res.status(404).json({
          success: false,
          message: 'Documento non trovato'
        });
      }
      
      res.json({
        success: true,
        data: document
      });
    } catch (error) {
      console.error('Error fetching document:', error);
      res.status(500).json({
        success: false,
        message: 'Errore nel recupero del documento'
      });
    }
  },

  async downloadDocument(req, res) {
    try {
      const { id } = req.params;
      const document = await Document.findByPk(id);
      
      if (!document) {
        return res.status(404).json({
          success: false,
          message: 'Documento non trovato'
        });
      }
      
      const filePath = path.resolve(__dirname, '../../', document.file_path);
      
      if (!fs.existsSync(filePath)) {
        return res.status(404).json({
          success: false,
          message: 'File non trovato sul server'
        });
      }
      
      res.download(filePath, document.file_name);
    } catch (error) {
      console.error('Error downloading document:', error);
      res.status(500).json({
        success: false,
        message: 'Errore nel download del documento'
      });
    }
  }
};

module.exports = documentController;