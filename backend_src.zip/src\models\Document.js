const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Document = sequelize.define('Document', {
  id: {
    type: DataTypes.STRING,
    primaryKey: true,
    allowNull: false
  },
  doc_type: {
    type: DataTypes.STRING,
    allowNull: false
  },
  file_name: {
    type: DataTypes.STRING,
    allowNull: false
  },
  file_path: {
    type: DataTypes.STRING,
    allowNull: false
  },
  file_size: {
    type: DataTypes.INTEGER
  },
  description: {
    type: DataTypes.TEXT
  },
  is_public: {
    type: DataTypes.BOOLEAN,
    defaultValue: true
  },
  uploaded_by: {
    type: DataTypes.STRING,
    allowNull: false
  },
  created_at: {
    type: DataTypes.DATE,
    allowNull: false
  },
  updated_at: {
    type: DataTypes.DATE
  }
}, {
  tableName: 'documents',
  timestamps: false
});

module.exports = Document;