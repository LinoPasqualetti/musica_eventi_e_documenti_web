const sequelize = require('../config/database');
const Event = require('./Event');
const Song = require('./Song');
const Document = require('./Document');

// RELAZIONI Event - Song (tramite event_songs)
Event.belongsToMany(Song, {
  through: 'event_songs',
  foreignKey: 'event_id',
  otherKey: 'song_id',
  as: 'songs'
});

Song.belongsToMany(Event, {
  through: 'event_songs',
  foreignKey: 'song_id',
  otherKey: 'event_id',
  as: 'events'
});

// RELAZIONI Document - Song (tramite song_documents)
Document.belongsToMany(Song, {
  through: 'song_documents',
  foreignKey: 'document_id',
  otherKey: 'song_id',
  as: 'songs'
});

Song.belongsToMany(Document, {
  through: 'song_documents',
  foreignKey: 'song_id',
  otherKey: 'document_id',
  as: 'documents'
});

console.log('✅ Modelli caricati con relazioni:');
console.log(`  - Event: ${typeof Event}`);
console.log(`  - Song: ${typeof Song}`);
console.log(`  - Document: ${typeof Document}`);

module.exports = {
  sequelize,
  Event,
  Song,
  Document
};