const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Song = sequelize.define('Song', {
  id: {
    type: DataTypes.STRING,
    primaryKey: true,
    allowNull: false
  },
  title: {
    type: DataTypes.STRING,
    allowNull: false
  },
  composer: {
    type: DataTypes.STRING
  },
  created_by: {
    type: DataTypes.STRING,
    allowNull: false
  },
  created_at: {
    type: DataTypes.DATE,
    allowNull: false
  },
  updated_at: {
    type: DataTypes.DATE
  },
  difficulty: {
    type: DataTypes.STRING
  },
  genre: {
    type: DataTypes.STRING
  },
  duration_seconds: {
    type: DataTypes.INTEGER
  },
  tempo: {
    type: DataTypes.INTEGER
  },
  key_signature: {
    type: DataTypes.STRING
  },
  time_signature: {
    type: DataTypes.STRING
  },
  lyrics: {
    type: DataTypes.TEXT
  }
}, {
  tableName: 'songs',
  timestamps: false
});

module.exports = Song;